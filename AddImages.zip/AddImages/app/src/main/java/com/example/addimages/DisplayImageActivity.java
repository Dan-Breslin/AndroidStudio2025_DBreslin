package com.example.addimages;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

public class DisplayImageActivity extends AppCompatActivity {

    Button back_button;
    ImageView imageView;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_display_image);

        back_button = (Button) findViewById(R.id.buttonBack);
        imageView = (ImageView) findViewById(R.id.imageView);

        Bundle extras = getIntent().getExtras();
        String msg = extras.getString("selectedRadioButton");
        switch (msg) {
            case "drawable":
                imageView.setImageResource(R.drawable.die_face_1);
                break;
            case "sdcard":
                String filename ="/sdcard/Images/die_face_2.jpg";
                Bitmap bitmap = BitmapFactory.decodeFile(filename);
                imageView.setImageBitmap(bitmap);
                break;
        }
        back_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(DisplayImageActivity.this, MainActivity.class);
                startActivity(intent);
            }
        });
    }
}