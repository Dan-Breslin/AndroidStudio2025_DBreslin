package com.example.cw1;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

import java.util.BitSet;

public class MainActivity extends AppCompatActivity {

    ImageView imv1;

    ImageView imv2;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        imv1 = (ImageView) findViewById(R.id.imageView);
        imv2 = (ImageView) findViewById(R.id.imageView2);

        // Deisplay Image 1
        String fileName1 = "/sdcard/images/die_face_1.jpg";
        Bitmap bitmap1 = BitmapFactory.decodeFile(fileName1);
        imv1.setImageBitmap(bitmap1);

        // Deisplay Image 2
        String fileName2 = "/sdcard/images/die_face_2.jpg";
        Bitmap bitmap2 = BitmapFactory.decodeFile(fileName2);
        imv2.setImageBitmap(bitmap2);
    }

    public void RandomImage(View view){

        // Define the Range
        int max = 2;
        int min = 1;
        int range = max- min + 1;

        int rand1 = (int)(Math.random()* range) + min;
        String fn1 = "/sdcard/images/die_face_" + Integer.toString(rand1) + ".jpg";
        Bitmap bmap1 = BitmapFactory.decodeFile(fn1);
        imv1.setImageBitmap(bmap1);

        int rand2 = (int)(Math.random()* range) + min;
        String fn2 = "/sdcard/images/die_face_" + Integer.toString(rand2) + ".jpg";
        Bitmap bmap2 = BitmapFactory.decodeFile(fn2);
        imv2.setImageBitmap(bmap2);

    }
}