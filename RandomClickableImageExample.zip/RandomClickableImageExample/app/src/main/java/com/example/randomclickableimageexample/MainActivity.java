package com.example.randomclickableimageexample;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

public class MainActivity extends AppCompatActivity {

    String [] filename = {"die_face_1.jpg", "die_face_2.jpg"};

    public static int max = 2 ;
    public static int min = 1 ;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ImageView imView1 = findViewById(R.id.imageView1);
        ImageView imView2 = findViewById(R.id.imageView2);
        Button button = (Button) findViewById(R.id.button);

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int randNumber1 = randomNumbers(min, max);
                String fileStr1 = filename[randNumber1 - 1];

               String first_file = "/sdcard/Images/" + fileStr1;
                Bitmap bitmap1 = BitmapFactory.decodeFile(first_file);
                imView1.setImageBitmap(bitmap1);

                int randNumber2 = randomNumbers(min, max);
                String fileStr2 = filename[randNumber2 - 1];

                String second_file = "/sdcard/Images/" + fileStr2;
                Bitmap bitmap2 = BitmapFactory.decodeFile(second_file);
                imView2.setImageBitmap(bitmap2);

                System.out.println("Size is : " + first_file + " and " + second_file);
            }
        });
    }

    public int randomNumbers(int min, int max){
        int rande = max - min + 1;
        int randNumber = (int)(Math.random() * rande) + min;
        return randNumber;
    }
}